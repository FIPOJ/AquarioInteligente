#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "ds18b20.h"
#include "driver/gpio.h"

// Define os pinos dos dispositivos principais
#define AQUECEDOR_PIN GPIO_NUM_26
#define BOLHAS_PIN GPIO_NUM_27
#define VENTILADOR_PIN GPIO_NUM_25

// Define os pinos dos LEDs
#define AZUL_PIN GPIO_NUM_33
#define VERDE_PIN GPIO_NUM_32
#define VERMELHO_PIN GPIO_NUM_22
#define AMARELO_PIN GPIO_NUM_23

// Define o pino do buzzer
#define BUZZER_PIN GPIO_NUM_21

// Define o pino do sensor DS18B20
#define GPIO_DS18B20 19

static const char *TAG = "APP";

// Função para inicializar os pinos
void inicializa_pinos() {
    gpio_config_t io_conf;
    io_conf.intr_type = GPIO_INTR_DISABLE;       // Desativa interrupções
    io_conf.mode = GPIO_MODE_OUTPUT;             // Configura como saída
    io_conf.pin_bit_mask = (1ULL << AQUECEDOR_PIN) | 
                           (1ULL << BOLHAS_PIN) | 
                           (1ULL << VENTILADOR_PIN) |
                           (1ULL << AZUL_PIN) |
                           (1ULL << VERDE_PIN) |
                           (1ULL << VERMELHO_PIN) |
                           (1ULL << AMARELO_PIN) |
                           (1ULL << BUZZER_PIN); // Inclui o buzzer
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE; // Desativa pull-down
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;     // Desativa pull-up
    gpio_config(&io_conf);

    // Inicializa todos os pinos desligados
    gpio_set_level(AQUECEDOR_PIN, 0);
    gpio_set_level(BOLHAS_PIN, 0);
    gpio_set_level(VENTILADOR_PIN, 0);
    gpio_set_level(AZUL_PIN, 0);
    gpio_set_level(VERDE_PIN, 0);
    gpio_set_level(VERMELHO_PIN, 0);
    gpio_set_level(AMARELO_PIN, 0);
    gpio_set_level(BUZZER_PIN, 0);
}

// Função para alternar os LEDs sequencialmente
void alternar_leds() {
    gpio_num_t leds[] = {AZUL_PIN, VERDE_PIN, VERMELHO_PIN, AMARELO_PIN};
    const char* cores[] = {"Azul", "Verde", "Vermelho", "Amarelo"};
    int num_leds = sizeof(leds) / sizeof(leds[0]);

    while (1) {
        for (int i = 0; i < num_leds; i++) {
            gpio_set_level(leds[i], 1);
            ESP_LOGI(TAG, "LED %s ligado", cores[i]);
            vTaskDelay(pdMS_TO_TICKS(2000)); // 2 segundos
            gpio_set_level(leds[i], 0);
            ESP_LOGI(TAG, "LED %s desligado", cores[i]);
        }
    }
}

// Função para controlar o buzzer
void buzzer_task() {
    while (1) {
        gpio_set_level(BUZZER_PIN, 1); // Liga o buzzer
        ESP_LOGI(TAG, "Buzzer ligado");
        vTaskDelay(pdMS_TO_TICKS(1000)); // 1 segundo

        gpio_set_level(BUZZER_PIN, 0); // Desliga o buzzer
        ESP_LOGI(TAG, "Buzzer desligado");
        vTaskDelay(pdMS_TO_TICKS(10000)); // 10 segundos
    }
}

// Função para ler a temperatura do sensor DS18B20
void leitura_temperatura_task() {
    float temperatura;
    ds18b20_init(GPIO_DS18B20);
    ESP_LOGI(TAG, "Sensor DS18B20 inicializado no GPIO %d", GPIO_DS18B20);

    while (1) {
        if (ds18b20_read_temperature(GPIO_DS18B20, &temperatura)) {
            ESP_LOGI(TAG, "Temperatura Atual: %.2f °C", temperatura);
        } else {
            ESP_LOGE(TAG, "Erro ao ler a temperatura do sensor!");
        }
        vTaskDelay(pdMS_TO_TICKS(2000)); // 2 segundos
    }
}

void app_main() {
    inicializa_pinos();

    // Cria uma tarefa separada para alternar os LEDs
    xTaskCreate(alternar_leds, "Alternar LEDs", 2048, NULL, 1, NULL);

    // Cria uma tarefa separada para o buzzer
    xTaskCreate(buzzer_task, "Buzzer Task", 2048, NULL, 1, NULL);

    // Cria uma tarefa para leitura da temperatura
    xTaskCreate(leitura_temperatura_task, "Leitura Temperatura", 2048, NULL, 1, NULL);

    // Loop alternado entre aquecedor, bolhas e ventilador
    while (1) {
        gpio_set_level(AQUECEDOR_PIN, 1);
        gpio_set_level(BOLHAS_PIN, 0);
        gpio_set_level(VENTILADOR_PIN, 0);
        vTaskDelay(pdMS_TO_TICKS(300000)); // 5 minutos

        gpio_set_level(AQUECEDOR_PIN, 0);
        gpio_set_level(BOLHAS_PIN, 1);
        gpio_set_level(VENTILADOR_PIN, 0);
        vTaskDelay(pdMS_TO_TICKS(300000)); // 5 minutos

        gpio_set_level(AQUECEDOR_PIN, 0);
        gpio_set_level(BOLHAS_PIN, 0);
        gpio_set_level(VENTILADOR_PIN, 1);
        vTaskDelay(pdMS_TO_TICKS(300000)); // 5 minutos
    }
}
